# SecureGuard Financial Fraud Analysis

1. Extract the complete ZIP into a local folder on Windows.
2. Open **SecureGuard.pbip** in an updated Power BI Desktop. If your Desktop build requires it, enable Power BI Project and the enhanced report format (PBIR) under **File → Options and settings → Options → Preview features**, then restart.
3. Run **Home → Refresh** on the first open to load the embedded transaction sample if the visuals are blank. The project has no external data path.
4. Use the Month, Category, State, and Gender dropdowns on each page. Click a chart mark to explore its relationship with the other visuals on that page. Click it again to clear the selection.
5. To share one local file, use **File → Save As** and select **Power BI Desktop files (.pbix)** after you confirm the visuals.

## Data and definitions

- The source is the supplied 20,000-row credit-card transaction CSV sample (January 2019 to June 2020). Baseline: **20,000 transactions, 112 labeled fraud cases, 0.56% fraud rate**.
- Fraud rate is labeled fraud cases divided by transactions in the current filter context. Flagged amount represents the transaction amount associated with labeled fraud cases.
- The model keeps month, week, weekday, hour, category, state, gender, amount band, amount, and fraud label. Names, payment card numbers, street addresses, exact coordinates, and transaction IDs are excluded.
- The weekly average uses an illustrative 2% annual adjustment to 2026 dollars. Transaction amounts are in USD.
- State comparisons use filterable bar charts. The amount distribution table shows the 25th percentile, median, and 75th percentile by category and gender.
- The project definitions and baseline data are checked locally. Report rendering requires Power BI Desktop on Windows.

## Branded report

The supplied artwork is embedded as individual images. It is also available in SecureGuard.Report/StaticResources/RegisteredResources for reuse. Monetary KPIs are in USD.

Each page uses its own canvas PNG. KPI, slicer, and chart-area icons are composited into the canvas behind the live Power BI visuals. Individual source PNGs remain in RegisteredResources.
